Changelog
---------

Version 1.2
~~~~~~~~~~~

* Fixed voice selection to use VoiceLocaleIdentifier on OS X instead of deprecated VoiceLanguage

Version 1.1
~~~~~~~~~~~

* Fixed compatibility with pip
* Fixed espeak crash when running on Natty (https://github.com/parente/pyttsx/issues/3)

Version 1.0
~~~~~~~~~~~

First release